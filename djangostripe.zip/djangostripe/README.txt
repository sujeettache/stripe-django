#install the basic requirements of the project. This project build on Python 3.6 and configured in Postgresql.

Use Virtual Enviroment for the requirements
>>virtualenv myenv
>>cd myenv>scripts
>>activate
(myenv)>>pip install django
(myenv)>>pip install stripe
(myenv)>>pip install psycopg2

#Postgresql
>>Go to ur psql cmd
1. login in psql
2. \l for list all DB
3. CREATE DATABASE stripe;  #create database into postgres
4. \c stripe: #connect your database 
5. Enter your postgres credentials in settings.py file

After all

Go to your root directory of django
1. python manage.py migrate
2. python manage.py runserver